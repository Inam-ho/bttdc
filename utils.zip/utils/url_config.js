export const API_URL = "http://localhost:8000";
// export const API_URL = "https://bttdc.nazmul.xyz";