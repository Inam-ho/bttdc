import React from 'react'

const DoctorsInfo = () => {
  return (
    <div>DoctorsInfo</div>
  )
}

export default DoctorsInfo