import CourseTable from "../Table/CourseTable";

const Courses = () => {
  return (
    <div>
      <CourseTable />
    </div>
  );
};

export default Courses;
