import React from 'react'

const Office = () => {
  return (
    <div>Office</div>
  )
}

export default Office