import EmergencyAnnouncementComp from "../components//EmergencyAnnouncement/EmergencyAnnouncement";
const EmergencyAnnouncement = () => {
  return (
    <div className="">
      <EmergencyAnnouncementComp />
    </div>
  );
};

export default EmergencyAnnouncement;
