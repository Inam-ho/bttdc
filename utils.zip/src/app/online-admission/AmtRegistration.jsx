import AMTRegistrationForm from '../../components/OnlineAdmission/AMTRegistrationForm';

const AmtRegistration = () => {
    return (
        <div>
            <AMTRegistrationForm/>
        </div>
    );
};

export default AmtRegistration;