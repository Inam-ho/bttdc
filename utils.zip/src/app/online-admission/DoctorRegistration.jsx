
const DoctorRegistration = () => {
    return (
        <div>
            <h1>Doctor</h1>
        </div>
    );
};

export default DoctorRegistration;