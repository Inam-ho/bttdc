import OnlineAdmissionCom from "../../components/OnlineAdmission/OnlineAdmission";
const OnlineAdmission = () => {
  return (
    <div className="">
      <OnlineAdmissionCom />
    </div>
  );
};

export default OnlineAdmission;
