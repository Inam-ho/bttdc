import Notices from "../components/Notice/Notice";

const Notice = () => {
  return (
    <div className="container mx-auto">
      <Notices />
    </div>
  );
};

export default Notice;
