import CourseTable from "../components/Table/CourseTable";

const DiplomaCourses = () => {
  return (
    <div className="">
    <CourseTable/>
    </div>
  );
};

export default DiplomaCourses;
