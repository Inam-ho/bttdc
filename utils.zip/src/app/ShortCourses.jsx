import CourseTable from "../components/Table/CourseTable";

const ShortCourses = () => {
  return (
    <div className="">
      <CourseTable/>
    </div>
  );
};

export default ShortCourses;
