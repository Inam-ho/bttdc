import ResultCom from "../components/Result/Result";
const Result = () => {
  return (
    <div className="">
      <ResultCom />
    </div>
  );
};

export default Result;
