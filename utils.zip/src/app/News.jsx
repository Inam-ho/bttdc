import NewsComp from '../components/News/News';
const News = () => {
    return (
        <div>
            <NewsComp/>
        </div>
    );
};

export default News;