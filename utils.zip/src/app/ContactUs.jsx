import Contact from "../components/Contact/Contact";
const ContactUs = () => {
  return (
    <div className="">
     <Contact/>
    </div>
  );
};

export default ContactUs;
