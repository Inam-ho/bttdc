import AboutUsComp from "../components/AboutUs/AboutUs";

const AboutUs = () => {
  return <AboutUsComp />;
};

export default AboutUs;
