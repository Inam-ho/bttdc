import CoursesComp from "../components/Courses/Courses";

const Courses = () => {
  return <CoursesComp />;
};

export default Courses;
