import AuthorityAphorismComp from "../components/AuthorityAphorism/AuthorityAphorism";
const AuthorityAphorism = () => {
    return (
        <div>
            <AuthorityAphorismComp/>
        </div>
    );
};

export default AuthorityAphorism;