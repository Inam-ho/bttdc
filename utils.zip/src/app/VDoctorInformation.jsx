import VDoctorInformationComponent from "../components/VDoctorInformation/VDoctorInformation";
const VDoctorInformation = () => {
  return (
    <div className="">
      <VDoctorInformationComponent />
    </div>
  );
};

export default VDoctorInformation;
