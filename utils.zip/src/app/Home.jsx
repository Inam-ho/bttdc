import HomeComp from "../components/Home/Home";

const Home = () => {
  return (
    <>
      <HomeComp />
    </>
  );
};

export default Home;
