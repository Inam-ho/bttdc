import ApplyForInstituteComp from "../components/ApplyForCertificate/ApplyForInstitute";
const ApplyForInstitute = () => {
  return (
    <div>
      <ApplyForInstituteComp />
    </div>
  );
};
export default ApplyForInstitute;
