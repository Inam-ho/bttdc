import CourseTable from "../components/Table/CourseTable";

const BSCCourses = () => {
  return (
    <div className="">
      <CourseTable />
    </div>
  );
};

export default BSCCourses;
