import AcademicComp from "../components/Academic/Academic";

const Academic = () => {
  return <AcademicComp />;
};

export default Academic;
