import Branch from "../components/Branch/Branch";

const BranchOffice = () => {
  return (
    <div className="">
     <Branch/>
    </div>
  );
};

export default BranchOffice;
