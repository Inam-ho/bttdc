export const bangladeshEmergencyContacts = [
    { service: "পুলিশ", number: "৯৯৯", link: "https://www.police.gov.bd/" },
    { service: "ফায়ার সার্ভিস", number: "৯৯৯", link: "http://www.fireservice.gov.bd/" },
    { service: "অ্যাম্বুলেন্স", number: "১৯৯", link: "https://dghs.gov.bd/" },
    { service: "জাতীয় হেল্পলাইন", number: "১০৯", link: "https://www.joy.gov.bd/" },
    { service: "নারী ও শিশু নির্যাতন প্রতিরোধ", number: "১০৯", link: "https://www.mowca.gov.bd/" },
    { service: "জাতীয় জরুরী সেবা", number: "৯৯৯", link: "https://999.gov.bd/" },
    { service: "পর্যটন পুলিশ", number: "+৮৮০১৭৬৯৬৯৬৯৯৯", link: "https://www.police.gov.bd/content.php?id=283" },
  ];
  